import React, { useEffect, useState } from "react";
import axios from "axios";
import "./HomePage.css"; // CSS dosyasını eklediğinizden emin olun

const HomePage = () => {
  const [stocks, setStocks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:1337/api/stocks", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setStocks(response.data.data || []);
      } catch (error) {
        console.error("Error fetching stocks:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  if (!stocks.length) {
    return <div className="no-stocks">No stocks available.</div>;
  }

  return (
    <div className="container">
      <h1>FinancAli</h1>
      <h2>Popular Stocks</h2>
      <div className="grid">
        {stocks.map((stock) => (
          <div className="card" key={stock.id}>
            <h3>{stock.Name}</h3>
            <p>Symbol: {stock.Symbol}</p>
            <p>Price: ${stock.Price}</p>
            <p>Change: {stock.Change}%</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;