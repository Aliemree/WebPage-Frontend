import React, { useEffect, useState } from "react";
import axios from "axios";

const StocksPage = () => {
  const [stocks, setStocks] = useState([]);
  const [loading, setLoading] = useState(true); // Yükleme durumu
  const [error, setError] = useState(null); // Hata mesajlarını tutmak için

  useEffect(() => {
    const fetchData = async () => {
      try {
        // localStorage'den token'ı alıyoruz
        const token = localStorage.getItem("token");

        // Axios ile GET isteği atıyoruz
        const response = await axios.get("http://localhost:1337/api/stocks", {
          headers: {
            // JWT token eklemek için Authorization başlığı kullanıyoruz
            Authorization: `Bearer ${token}`,
          },
        });
        
        // Gelen veride 'data' dizisini state'e kaydediyoruz
        setStocks(response.data.data || []);
      } catch (error) {
        // Hata durumunu state'e kaydediyoruz
        console.error("Error fetching stocks:", error);
        setError(error.message || "Bir hata oluştu");
      } finally {
        // Yükleme tamamlandı
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Eğer veriler yükleniyorsa
  if (loading) {
    return <div>Loading...</div>;
  }

  // Eğer API çağrısında bir hata oluştuysa
  if (error) {
    return <div>Hata: {error}</div>;
  }

  // Eğer veri yoksa
  if (!stocks.length) {
    return <div>No stocks available.</div>;
  }

  return (
    <div style={{ padding: "20px" }}>
      <h1>Stocks Page</h1>
      <h2>All Stocks</h2>
      <ul>
        {stocks.map((stock) => (
          <li key={stock.id} style={{ marginBottom: "10px", listStyle: "none" }}>
            <h3>{stock.Name}</h3>
            <p>Symbol: {stock.Symbol}</p>
            <p>Price: ${stock.Price}</p>
            <p>Change: {stock.Change}%</p>
            
            {stock.isPopular && (
              <p style={{ color: "green" }}>This stock is popular!</p>
            )}

            {/* Örnek olarak HistoricalData alanını da göstermek istersek */}
            {stock.HistoricalData && (
              <div>
                <strong>Historical Data:</strong>
                {Object.entries(stock.HistoricalData).map(([date, details]) => (
                  <div key={date}>
                    <span>{date} - Price: {details.price}, Volume: {details.volume}</span>
                  </div>
                ))}
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StocksPage;